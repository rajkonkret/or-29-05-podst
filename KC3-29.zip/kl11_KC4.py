class MyException(Exception):
    def __init__(self, message):
        super().__init__(message)

try:
    raise MyException("błąd wystąpił")
except Exception as e:
    print(e)


