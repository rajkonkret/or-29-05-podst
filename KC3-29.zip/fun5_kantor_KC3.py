kurs_euro = 4.5

def kantor(waluta):
    print("uruchomienia kantoru")

    def usd(kwota=0):
        print("przeliczam dolary", kwota * 4.13)

    def eur(kwota=0):
        print("przeliczam euro", kwota * kurs_euro)

    if waluta == 'eur':
        return eur
    else:
        return usd


moj_kantor_eur = kantor("eur")
print(moj_kantor_eur)
moj_kantor_eur(1000)

moj_kantor_usd = kantor("usd")
moj_kantor_usd
moj_kantor_usd(1000)