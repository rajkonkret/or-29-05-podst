import math

pi = math.pi
print(pi)

def pierw(numer):
    pierwiastek = math.sqrt(numer)
    return pierwiastek

print(pierw(25))

a = pierw(25)
a = 4.4
b = int(a)
print(b)
print(round(a))
a = int(round(a))
print(a)
print(type(a))


