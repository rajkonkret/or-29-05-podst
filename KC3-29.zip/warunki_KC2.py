# odp = True # prawda do zmiennej odp
#
# if odp:  # jeżeli warunek jest True to wykonujemy kod z wciecia
#     print("Brawo")
#
# odp = 20
# print(type(odp))
# if odp: # <class 'int'> zrzutował na bool , wszystko inne niz 0 jest prawda
#     print("Brawo2")
#
# czy_znasz_Python = 'n'
# if czy_znasz_Python == 't':
#     print("Brawo")
# else:
#     print("uczymy się dalej")
#
# print("Program działa nadal")
#
# podatek = 0.0  # float
# zarobki = int(input("Dochód")) # pobieramy odpowiedz uzytkownika, input zawsze zwraca str
# # jezeli dokonac obliczenia na danych od uzutkownika to nalezaloby zamienic na liczby (int lub float)
#
# if zarobki < 10000:
#     podatek = 0.0
#
# elif zarobki < 20000:
#     podatek = 0.4
#
# elif zarobki < 300001:
#     podatek = 0.2
#
# elif zarobki < 700001:
#     podatek = 0.1
#
# else:
#     podatek = 0.6
#
# print(f"Zapłacisz{zarobki * podatek}zł")
#
#
# suma_zam = 150
# if suma_zam > 100:
#     rabacik = 25
# else:
#     rabacik = 0
#
# print(f"Rabacik{rabacik}")
#
# rabat = 25 if suma_zam > 100 else 0
# print(f"Rabacik {rabat}")


lista_blendow = []
alert_system = 'email'
error = 'medium'
error_mesage = "Stało się coś strasznego"

if alert_system == 'console':
    print(error_mesage)
elif alert_system == 'email':
    if error == 'medium':
        lista_blendow.append('ostrzeżenie')
    elif error == 'critical':
        lista_blendow.append('krytyczny')
    else:
        lista_blendow.append('nieznany')
print(lista_blendow)


odp = input("Podaj date urodzenia")
if odp == "966":
    print("Prawidłowa odpowiedź")
else:
    print("Zapytaj mame")


for i in range(10):
    if i % 2 ==0:
        print(i, "jest parzysta")

lista2 = [j for j in range(10) if j% 2 == 0]
print(lista2)

for c in lista2:
    if c == 2:
        c += 1
    print(c)


