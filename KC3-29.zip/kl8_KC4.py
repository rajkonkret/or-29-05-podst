from abc import abstractmethod


class Ptak:
    """
    Klasa opisująca ptaka w Pythonie
    """

    def __init__(self, gatunek, szybkosc):
        self.gatunek = gatunek
        self.szybkosc = szybkosc

    def latam(self):
        print("TU", self.gatunek, "Lecę z prędkością", self.szybkosc)

    @abstractmethod
    def wydaj_odgłos(self):
        pass

class Orzel(Ptak):
    """
    Klasa Orzeł
    """

    def __init__(self, gatunek):
        super().__init__(gatunek, 0)
        self.gatunek = gatunek

    def wydaj_odgłos(self):
        print("piiiii piiiii")



class Kura(Ptak):
    """
    Klasa kura
    """

    def __init__(self, gatunek):
        super().__init__(gatunek, 0)
        self.gatunek = gatunek


    def wydaj_odgłos(self):
        print("ko ko koko")


Orzel = Ptak("Orzeł", 20)
Orzel.latam
Orzel.wydaj_odgłos()


kura = Ptak("Kura", 0)
kura.latam()
kura.wydaj_odgłos()
