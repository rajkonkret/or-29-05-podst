import requests
import xml.etree.ElementTree as ET

url = "http://api.nbp.pl/api/exchangerates/tables/A?format=xml"

response = requests.get(url)
print(response)

xml_data = response.content

print(xml_data)

root = ET.fromstring(xml_data)
table_name = root.find('.//Table').text
print(f"Tabela: {table_name}")

date = root.find('.//EffectiveDate').text
print(date)
rates = root.findall('.//Rate')

print(rates)

for rate in rates:
    currency = rate.find('Currency').text
    code = rate.find('Code').text
    mid = rate.find('Mid').text
    print(f"{code}: {currency} - {mid}")












