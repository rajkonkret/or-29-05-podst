# PEP8 - zasady czystego kodu
# ctrl alt l
print()  # wydrukuj/wypisz tekst który chcemy wyświetlićwpisujemy w nawiasie w cudzysłowi
print("Nazywam się Krzysiek")  # str - teksty
print('Nazywam się Krzysiek')  # str - teksty
# ctrl d - kopiowanie linii
# ctrl d - kopiowanie linii
print(39)  # int - liczby całkowite

print(type(39))  # wypisanie typu danej , <class 'int'>
print(type("Krzysiek"))  # <class 'str'>
print("39" + "15")  # 3915
print(39 + 15) # 54
print(5 * "4") # 44444

# zmienne - pudełko na dane
imie = "Krzysiek"
print(type(imie)) # <class 'str'>

print(imie) # wyswietlenie zawartosci zmiennej

wiek = 48
print(wiek)
print(type(wiek)) # <class 'int'>

wiek = "Krzysiek"
print(type(wiek)) # <class 'int'>
print(wiek)





