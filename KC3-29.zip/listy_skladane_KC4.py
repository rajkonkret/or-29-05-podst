numbers = [1, 2, 3, 4, 5, 7, 9]

squared = [num ** 2 for num in numbers]
print(squared)
#for num in numbers:
 #   jakaslista.append(x ** 2)

even_numbers = [num for num in numbers if num % 2 == 0]
#print(even_numbers)
#for num in numbers:
#    if num % 2 == 0:
#       jakaslista.append(num)

modifed_nummbers = [num * 2 if num % 2 == 0 else num for num in numbers]
print(modifed_nummbers)
#
#for num in numbers:
#    if num % 2 == 0:
#        jakaslista.append(num * 2)
#    else:
#       jakaslista.append(num)


even_odd = ["parzysta" if x % 2 == 0 else "nieparzysta" for x in numbers]
print(even_odd)

even_numbers_range = [num for num in range(10) if num % 2 == 0]
print(even_numbers_range)

squared_numbers = [x **2 for x in range(1, 6)]
print(squared_numbers)

numbers2 = [-1, -2, 3, -4, 5]
absolute_values = [abs(x) for x in numbers2]
print(absolute_values)

word = "Python"
letters = [letter for letter in word]
print(letters)


