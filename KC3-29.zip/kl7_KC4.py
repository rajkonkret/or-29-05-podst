class Animal:

    def __init__(self, imie):
        self.imie = imie

    def daj_glos(self):
        pass

    def info(self):
        print(f"Imię: {self.imie}")

class Dog(Animal):

    def __init__(self, imie, rasa):
        super().__init__(imie)
        self.rasa = rasa

    def daj_glos(self):
        print("hau hau!")

    def info(self):
        super().info()
        print((f"rasa: {self.rasa}"))

class Cat(Animal):

    def __init__(self, imie, kolor):
        super().__init__(imie)
        self.kolor = kolor

    def daj_glos(self):
        print("Miau Miau!")

    def info(self):
        super().info()
        print((f"kolor: {self.kolor}"))


class Tiger(Cat):
    def __init__(self, imie, kolor, liczba_paskow):
        super().__init__(imie, kolor)
        self.liczba_paskow = liczba_paskow

    def daj_glos(self):
        print("Arr Arr!")

    def info(self):
        super().info()
        print((f"liczba pasków: {self.liczba_paskow}"))



zwierze = Animal ("Bezimienny")
zwierze.info()
zwierze.daj_glos()

pies = Dog("Burek", "Kundel")
pies.info()
pies.daj_glos()

kot = Cat("Filemon", "Sary")
kot.info()
kot.daj_glos()

tygrys = Tiger("Rajah", "Pomarańczowy", 17)
tygrys.info()
tygrys.daj_glos()