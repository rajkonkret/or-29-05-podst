from datetime import date, timedelta, datetime

today = date.today()
time = datetime.now()

print(today)
print(type(today))
print(time)
print(type(time))

tommorow = today + timedelta(days=1)
print(tommorow)

print(today.year)
print(today.month)
print(time.hour)


products = [
    {'sku': '1', 'exp_date': today, 'price': 100.0},
    {'sku': '2', 'exp_date': tommorow, 'price': 50},
    {'sku': '3', 'exp_date': today, 'price': 20.0},
]

print(products)

for product in products:
    if product['exp_date'] != today:
        continue
    print(product)
    product['price'] *= 0.8