import tkinter as tk
import tkinter.font as tkFont

class App:
    def __init__(self, root):
        #setting title
        root.title("undefined")
        #setting window size
        width=600
        height=500
        screenwidth = root.winfo_screenwidth()
        screenheight = root.winfo_screenheight()
        alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
        root.geometry(alignstr)
        root.resizable(width=False, height=False)

        GButton_981=tk.Button(root)
        GButton_981["bg"] = "#f0f0f0"
        ft = tkFont.Font(family='Times',size=10)
        GButton_981["font"] = ft
        GButton_981["fg"] = "#000000"
        GButton_981["justify"] = "center"
        GButton_981["text"] = "Button"
        GButton_981.place(x=70,y=50,width=70,height=25)
        GButton_981["command"] = self.GButton_981_command

        GRadio_303=tk.Radiobutton(root)
        ft = tkFont.Font(family='Times',size=10)
        GRadio_303["font"] = ft
        GRadio_303["fg"] = "#333333"
        GRadio_303["justify"] = "center"
        GRadio_303["text"] = "RadioButton"
        GRadio_303.place(x=210,y=50,width=85,height=25)
        GRadio_303["command"] = self.GRadio_303_command

        GRadio_613=tk.Radiobutton(root)
        ft = tkFont.Font(family='Times',size=10)
        GRadio_613["font"] = ft
        GRadio_613["fg"] = "#333333"
        GRadio_613["justify"] = "center"
        GRadio_613["text"] = "RadioButton"
        GRadio_613.place(x=210,y=90,width=85,height=25)
        GRadio_613["command"] = self.GRadio_613_command

        GListBox_516=tk.Listbox(root)
        GListBox_516["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times',size=10)
        GListBox_516["font"] = ft
        GListBox_516["fg"] = "#333333"
        GListBox_516["justify"] = "center"
        GListBox_516.place(x=50,y=190,width=80,height=25)

        GMessage_488=tk.Message(root)
        ft = tkFont.Font(family='Times',size=10)
        GMessage_488["font"] = ft
        GMessage_488["fg"] = "#333333"
        GMessage_488["justify"] = "center"
        GMessage_488["text"] = "Message"
        GMessage_488.place(x=210,y=200,width=80,height=25)

        GLabel_875=tk.Label(root)
        ft = tkFont.Font(family='Times',size=10)
        GLabel_875["font"] = ft
        GLabel_875["fg"] = "#333333"
        GLabel_875["justify"] = "center"
        GLabel_875["text"] = "label"
        GLabel_875.place(x=30,y=260,width=70,height=25)

        GCheckBox_827=tk.Checkbutton(root)
        ft = tkFont.Font(family='Times',size=10)
        GCheckBox_827["font"] = ft
        GCheckBox_827["fg"] = "#333333"
        GCheckBox_827["justify"] = "center"
        GCheckBox_827["text"] = "CheckBox"
        GCheckBox_827.place(x=330,y=60,width=70,height=25)
        GCheckBox_827["offvalue"] = "0"
        GCheckBox_827["onvalue"] = "1"
        GCheckBox_827["command"] = self.GCheckBox_827_command

        GCheckBox_46=tk.Checkbutton(root)
        ft = tkFont.Font(family='Times',size=10)
        GCheckBox_46["font"] = ft
        GCheckBox_46["fg"] = "#333333"
        GCheckBox_46["justify"] = "center"
        GCheckBox_46["text"] = "CheckBox"
        GCheckBox_46.place(x=330,y=100,width=70,height=25)
        GCheckBox_46["offvalue"] = "0"
        GCheckBox_46["onvalue"] = "1"
        GCheckBox_46["command"] = self.GCheckBox_46_command

    def GButton_981_command(self):
        print("command")


    def GRadio_303_command(self):
        print("command")


    def GRadio_613_command(self):
        print("command")


    def GCheckBox_827_command(self):
        print("command")


    def GCheckBox_46_command(self):
        print("command")

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
