class Pojazd:
    def __init__(self, kolor):
        self.kolor = kolor

    def info(self):
        print(f"Kolor: {self.kolor}")


class Samohod(Pojazd):
    def __init__(self, kolor, marka):
        super().__init__(kolor)
        self.marka = marka


pojazd = Pojazd("biały")
pojazd.info()

samochod - Samohod("Czerwony", "Tesla")
samochod.info()
