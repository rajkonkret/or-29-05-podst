user ="Krzysiek"  # str
wiek = 54 # int
wersja = 3.9000001  # float - zmiennoprzecinkowa
liczba = 134578932  # int

# %s - str
# %d - liczba calkowita
print("Witamy %s maszteraz %d lat" % (user, wiek))
# ctrl / - komentarz linijki lub zaznaczonego bloku
# print("Witamy %s maszteraz %d lat" % (wiek, user)) - nie zadziała - %s oczekuje str dostaie int

print("Witamy %(user)s masz teraz %(age)d lat" % {'user':user, "age": wiek})
print("Witamy {} masz teraz {} lat".format(user, wiek))
print("Witamy {} masz teraz {} lat".format(wiek,user)) # zadziała ale nie tak jak oczekujemy
print(f"Witamy {user} masz teraz {wiek} lat") # f -fstring -sformatowany string

print("Uzywamy wersji Phyton %i" % 3)
print("Uzywamy wersji Phyton %.1f" % 3.9)
print("Uzywamy wersji Phyton %.2f" % 3.9)
print("Uzywamy wersji Phyton %.f" % 3.9)


print(F"Uzywamy wersji {wersja}") # używamy wersji 3.9000001
print(F"Uzywamy wersji {wersja:.1f}")
print(F"Uzywamy wersji {wersja:.2f}") # Używamy wersji 3.90

print(f"{user:>10}") # " Tomek" - uzupełnia spacje tak aby tekst miał 10 znaków
print(f"{user:>20}") # " Tomek" - uzupełnia spacje tak aby tekst miał 20 znaków
print(f"{user:<30}") # " Tomek" - dodał z prawej strony spacje by tekst
print(f"{user[0:4]}") # wyświetli pierwsze 4 od 0 do 3 ogranicza od 0 do 4 znaków

print(liczba) # 123456787654
print("Nazwa duza lciczba {:,}".format(liczba)) # nasza duza liczba 123,456,787,654
print("Nazwa duza lciczba {:,}".format(liczba).replace(",")) # nasza duza liczba 123,456,787,654
print("Nazwa duza lciczba {:,}".format(liczba)) # nasza duza liczba 123,456,787,654













