# lista - kolekcja do przechowywania elementów
lista = []  # pusta lista
print(type(lista))  # <class 'list'>
print(lista) # []
lista.append("Krzysiek")  # dodawanie elementu do listy
print(lista) # [Krzysiek']
lista.append("Maciek")
lista.append("Zenek")
lista.append("Jacek")
lista.append("Piotr")
lista.append("Tadek")
lista.append("Jacek")
print(lista) # ['Krzysiek', 'Maciek', 'Zenek', 'Jacek']
# indeksowana  od 0 - czyli pierwszy element ma indeks 0
print(lista[0])
print(lista[1])
print(lista[2])
# print(lista[10]) # Index Error: list index out of range
print(lista[-2])
print(len(lista)) # długość kolekcji=7 elementów, czyli ostatni ma index=6
print(lista[-1]) # Krzysiek ostatni element z listy
print(lista[-7])

# zastąpienie elementu o podanym indeksie
lista[2] = "Mikołaj"
print(lista)  # ['Krzysiek', 'Maciek', 'Mikołaj', 'Jacek', 'Piotr', 'Tadek', 'Jacek']

# wstawianie elementu na wskazany indekx
lista.insert(1, "Paweł")
print(lista)  # ['Krzysiek', 'Paweł', 'Maciek', 'Mikołaj', 'Jacek', 'Piotr', 'Tadek', 'Jacek']

# usunięcie z listy
lista.remove("Mikołaj")
print(lista)  # ['Krzysiek', 'Paweł', 'Maciek', 'Jacek', 'Piotr', 'Tadek', 'Jacek']

# usunięcie pierwszego napotkanego
lista.remove("Jacek")
print(lista)  # ['Krzysiek', 'Paweł', 'Maciek', 'Piotr', 'Tadek', 'Jacek']

# usunięcie po indeksie
indeks = lista.index ("Tadek")
print(indeks)

print(lista.pop(indeks)) # zwraca co usunięto
print(lista)

print(lista.pop(2))  # zwraca co usunięto

lista_copy = lista.copy()
print(lista_copy)

# usunięcie całej listy
lista.clear()
print(lista)

# tylko kopia adresu pamieci, obie listy wskazują te same elementy w pamięci
# obie naraz modyfikowane
print(lista_copy)
lista_copy.append("A")
lista_copy2 = lista_copy
print(lista_copy2)
print(lista_copy)

print("Jacek" in lista_copy2)  # True
liczby = [54, 999, 34, 22, 12.34, 687]
print(liczby)
liczby.sort()
print(liczby)

liczby.reverse()
print(liczby)  # [999, 687, 54, 34, 22, 12.34]

liczby[2] = 6666
print(liczby)
print(liczby [0:3])  # od indeksu 0..2
print(liczby [-2])
print(liczby [:-2])  # od do -3 ( -2 już nie wchodzi)
print(liczby [2:])   # od 2 do końca

liczby.remove(34)
print(liczby)
print(len(liczby)) # długość kolekcji

krotka = tuple(liczby) # zamiana listy na krotke
print(krotka) # (999, 687, 6666, 22, 12.34)
print(type(krotka))  # <class 'tuple'>



































