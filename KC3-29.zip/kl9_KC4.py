# wielodziedziczenie

class A:
    def method(self):
        print("Metoda z klasy A")

class B:
    def method(self):
        print("Metoda z klasy B")

class C(A, B):
    """
    klasa C dziedziczy po A i B

    """
    def method(self):
        #super().method()
        B.method(self) # jawne skazanie klasy z której ma się wykonać metoda

a = A()
a.method()
b= B()
b.method()

c = C()
c.method()
print(C.__mro__)

