def allparams(a, b, /, c=42, *args, d=256, **kwargs):
    print("a,b", a, b)
    print("c,d", c, d)
    print("c", c)
    print("args", args)
    print("kwargs", kwargs)

allparams(1, 2)
allparams(1, 2, c=9)
allparams(1, 2, 3)
allparams(1, 2, 3, 4, 5, 6, 7, 8, 9, 0)
allparams(1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 22, 33, 44, 55, 755, 999, 00, 89, 00, 00)
allparams(1, 2, 3, 4, 5, 6, 7, 8, d=8)
allparams(1, 2, 3, 4, 5, 6, 7, 8, d=8, radek="/")
allparams(1, 2, 3, 4, 5, 6, 7, 8, d=8, radek="/", zone="zone", a=1)





