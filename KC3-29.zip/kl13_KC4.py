import pickle
from dataclasses import dataclass

@dataclasses
class Person:
    first_name: str
    last_name: str
    id: int

    def greet(self):
        print(f"Witam, jestem {self.first_name} {self.last_name}, ID to {self.id}")

#if __name__ == '__main__':

people = [
    Person("Jacek", "Kowalski", 1),
    Person("Mateusz", "Zegan", 2)
]
print(people)
print(people[0])

with open('data.picle', 'wb') as stream:
    pickle.dump(people, stream)
