# dekorator -

import time


def dekor(funk):
    def wew():
        print("Dekorujemy")
        return funk()

    return wew

def measure_time(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"czas wykonania funkcji {func.__name__}: {execution_time} sec")

        return result

    return wrapper

@dekor
def hej():
    print("Hej")


@measure_time
def my_function():
    # pass
    time.sleep(2)

hej()
dekor(hej())

my_function()
