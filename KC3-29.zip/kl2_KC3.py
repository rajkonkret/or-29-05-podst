class Human:
    """Dokumentacja
    """

    def __init__(self, imie, wiek, wzrost, plec):
        self.imie = imie
        self.wiek = wiek
        self.wzrost = wzrost
        self.plec = plec

    def powitanie(self):
        print(f"Nazywam się {self.imie}")

    def moj_wiek (self):
            print(f"Nazywam się", self.imie, "Mam" self.wiek ="lat")

    def moj_wzrost (self):
            print(f"Nazywam się", self.imie, "Mam", self.wiek "lat", "Mam", self.wzrost = "wzrostu" )



cz1 - Human ("Krzysiek", "45", "182", "m")
print(cz1)
cz1.powitanie()
cz1.moj_wiek()
cz1.wzrost()
cz1.ruszaj()



