def dodaj(a, b):
    c = a + b
    return c


def oblicz_vat(cena, vat=23):
    return cena * (100 + vat) / 100


print(dodaj(5, 6))
print(dodaj(dodaj(1, 2), 5))
print(oblicz_vat(1000, 23))
print(oblicz_vat(1000))
print(oblicz_vat(1000, 7))

zm = oblicz_vat(1000)
if zm == 1230:
    print("Prawidłowo")
