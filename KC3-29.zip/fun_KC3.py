# funkcja

a = 5
b = 8


def dodaj():
    print(a + b)


def dodaj2(a, b):
    print(a + b)

def odejmij(a, b, c=0):
    print(a + b - c)


dodaj()
b = 7
dodaj()
dodaj2(8, 9)
odejmij(1, 2, 3)
odejmij(5, 7)

odejmij(b=6, a=9, c=8)

print(dodaj())