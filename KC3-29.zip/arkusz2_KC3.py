import pandas as pd

excel_dada = pd.read_excel('sales.xlsx')

data = pd.DataFrame(excel_dada)

print("The content is:\n", data)
