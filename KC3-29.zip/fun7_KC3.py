# argument słownikowe

def connect(**opcje):
    print(opcje)
    print(type(opcje))
    conect_pram = {
        'host': '127.0.0.7',
        'port': '8080'
    }
    print(conect_pram)
    conect_pram['pwd'] = opcje
    print(conect_pram)

    conect_pram.update({'pwd2': opcje})
    print(conect_pram)

connect()
connect(a=7)
connect(a=7, b=9)
connect(user="/home", root="/")
