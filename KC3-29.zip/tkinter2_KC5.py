import tkinter as tk


def on_click():
    print("Przycisk został naciśnęty")


app = tk.Tk()
