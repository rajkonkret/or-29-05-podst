import csv

#

fileds = ['name', 'branch', 'year', 'cgpa']

my_list_dict = [
    {'branch':'COE', 'cgpa': '9.1', 'name': 'Radek', 'year': '2'},
    {'branch':'COE', 'cgpa': '9.1', 'name': 'Radek', 'year': '2'},
]

filename = 'records.csv'

with open(filename, 'w', newline='') as csv_f:
    csvwriter=csv.DictWriter(csv_f, fieldnames=fileds)
    csvwriter.writeheader()
    csvwriter.writerows(my_list_dict)
