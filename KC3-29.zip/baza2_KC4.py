import sqlite3

try:
    sql_connection = sqlite3.connect('sqlite_python.db')

    query = '''
    CREATE TABLE SqliteDb_developers (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email text NOT NULL UNIQUE,
    jojning_date datetime,
    salary REAL NOT NULL);
    '''
    cursor = sql_connection.cursor()
    print("Baza została podłączona...")

    cursor.execute(query)
    sql_connection.commit()

except sqlite3.Error as e:
    print("Błąd podczas podłązcenia bazy", e)

finally:
    if sql_connection:
        sql_connection.close()
        print('Baza została zamknięta')