def liczby(*cyfry):
    print(cyfry)
    suma = 0
    print(type(cyfry))
    for cy in cyfry:
        suma += cy
    print(f"Suma: {suma}")
    count = len(cyfry)
    print(f"Liczba ocen:{count}")
    try:
        print(f"średnia wynosi {suma / count}")
    except Exception as e:
        print("Wystąpił błąd", e)


liczby()
liczby(1)
liczby(1, 2, 3, 4, 5)
