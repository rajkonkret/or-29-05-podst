import pandas as pd


data = pd.read_csv('records.csv')

print(data)
print(data.columns)

print(type(data))
print(data.values)
print(data.values[0])
print(data.items)