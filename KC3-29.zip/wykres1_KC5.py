import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
y = [2, 3, 5, 7, 9]

plt.plot(x, y)
plt.title("Wykres liniowy")
plt.xlabel('Oś x')
plt.ylabel('Oś y')

plt.show()

