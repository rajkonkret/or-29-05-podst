class Dom:
    """
    To jest klasa dom
    """

    def __init__(self, metraz, kolor, liczba_okien):
        self.__metraz = metraz
        self.__kolor = kolor
        self.__liczba_okien = liczba_okien

    def podaj_metraz(self):
        print("Metraż wynosi", self.__metraz)

    def podaj_kolor(self):
        print("Kolor domu to", self.__kolor)

    def podaj_ile_okien(self):
        print("Liczba okien", self.__liczba_okien)

dom1 = Dom(175, "czerwony", 8)
dom1.podaj_kolor()
dom1.podaj_metraz()
dom1.podaj_ile_okien()



