import requests as re


url = 'http://api.nbp.pl/api/exchangerates/rates/A/EUR/'

response = re.get(url)
print(response)

table = response.json()
print(table)

print(table['rates'])
print(table['rates'][0])
print(table['rates'][0]['mid'])

