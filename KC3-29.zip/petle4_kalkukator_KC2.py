# kalkulator
# menu
# wybór działania przez użytkownika
# podanie liczb na jakich wykonać działanie
# wyświetlenie wyniku działania

while True:
    print("""
    1. Dodawanie
    2. Odejmowanie
    3. Mnożenie
    4. Dzielenie
    5. Koniec
    """)

    odp = input("Podaj odpowiedź")
    if odp == '5':
        break

    a = int(input("Podaj pierwszą liczbę"))
    b = int(input("Podaj drugą liczbę"))

    if odp == '1':
        print("Dodawanie", a + b)

    elif odp == '2':
        print("Odejmowanie", a - b)

    elif odp == '3':
        print("Mnożenie", a * b)

    elif odp == '4':
        print("Dzielenie", a / b)

    else:
        print("Nie znam takiego działania")





