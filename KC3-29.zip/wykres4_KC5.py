import matplotlib.pyplot as plt

labels = ['2016', '2017', '2018']
values = [10, 20, 60, 35]

plt.bar(labels)