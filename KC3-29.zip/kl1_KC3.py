# klasa

class Human:
    """
    Klasa opisująca czlowieka w Phytonie
    """
    imie = ""
    wiek = None
    plec = ""

    def powitanie(self):
        print("nazywam się", self.imie)

    def moj_wiek(self):
        print("Nazywam się", self.imie, "Mam", self.wiek "lat")


print(Human.__doc__)
# print(print.__doc__)

cz1 = Human()
print(cz1)
print(cz1.imie)
cz1.imie = "Radek"
print(cz1.imie)
cz1.plec = "K"
print(cz1.plec)
cz1.wiek = 44
print(cz1.wiek)
print(cz1)
cz1.powitanie()

cz2 = Human()
print(cz2)
cz2.imie = "Krzysiek"
print(cz2.imie)
cz2.plec = "M"
print(cz2.plec)
cz2.wiek = 54
print(cz2.wiek)
print(cz2)
cz2.powitanie()


