# set - zbior - przechowuje niezduplikowane elementy
# nie pamieta kolejnosci

lista = [44, 55, 66, 777, 33, 22, 11, 33, 11]
zbior = set(lista)  # zamiana listy na set

print(lista) # [44, 55, 66, 777, 33, 22, 11, 33, 11]

print(zbior) # {33, 66, 777, 11, 44, 22, 55}

zb2 = set()  # pusty zbior
print(zb2) # set()
zbior.add(33)
print(zbior)
zbior.add(18)
print(zbior)
zbior.add(18)
print(zbior)


print(zbior.pop())  # 33
print(zbior)  # {66, 777, 11, 44, 18, 22, 55}
print(zbior.pop())  # 66
print(zbior) # {777, 11, 44, 18, 22, 55}
print(zbior.pop())  # 777
print(zbior)  # {11, 44, 18, 22, 55}


zbior.remove(55)
print(zbior)
zbior.remove(18)
print(zbior)

lista2 = list(zbior)
print(lista2)
print(type(lista2))















